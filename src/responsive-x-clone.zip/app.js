// Mobile menu functionality
class TwitterApp {
    constructor() {
        this.init();
    }

    init() {
        this.setupMobileMenu();
        this.setupFeedTabs();
        this.setupTweetComposer();
        this.setupTweetActions();
        this.setupFollowButtons();
        this.setupResponsiveHandlers();
    }

    // Mobile menu toggle
    setupMobileMenu() {
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        
        if (menuToggle && sidebar) {
            // Create overlay element
            const overlay = document.createElement('div');
            overlay.className = 'mobile-overlay';
            document.body.appendChild(overlay);

            menuToggle.addEventListener('click', () => {
                this.toggleMobileMenu(sidebar, overlay, menuToggle);
            });

            // Close menu when clicking overlay
            overlay.addEventListener('click', () => {
                this.closeMobileMenu(sidebar, overlay, menuToggle);
            });

            // Close menu when clicking outside or on navigation items
            sidebar.addEventListener('click', (e) => {
                if (e.target.closest('.nav-item')) {
                    this.closeMobileMenu(sidebar, overlay, menuToggle);
                }
            });

            // Handle escape key
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && sidebar.classList.contains('mobile-open')) {
                    this.closeMobileMenu(sidebar, overlay, menuToggle);
                }
            });
        }
    }

    toggleMobileMenu(sidebar, overlay, menuToggle) {
        const isOpen = sidebar.classList.contains('mobile-open');
        
        if (isOpen) {
            this.closeMobileMenu(sidebar, overlay, menuToggle);
        } else {
            this.openMobileMenu(sidebar, overlay, menuToggle);
        }
    }

    openMobileMenu(sidebar, overlay, menuToggle) {
        sidebar.classList.add('mobile-open');
        overlay.classList.add('active');
        menuToggle.classList.add('active');
        document.body.style.overflow = 'hidden';
        
        // Animate hamburger menu
        const spans = menuToggle.querySelectorAll('span');
        spans[0].style.transform = 'rotate(45deg) translate(5px, 5px)';
        spans[1].style.opacity = '0';
        spans[2].style.transform = 'rotate(-45deg) translate(7px, -6px)';
    }

    closeMobileMenu(sidebar, overlay, menuToggle) {
        sidebar.classList.remove('mobile-open');
        overlay.classList.remove('active');
        menuToggle.classList.remove('active');
        document.body.style.overflow = '';
        
        // Reset hamburger menu
        const spans = menuToggle.querySelectorAll('span');
        spans[0].style.transform = '';
        spans[1].style.opacity = '';
        spans[2].style.transform = '';
    }

    // Feed tabs functionality
    setupFeedTabs() {
        const feedTabs = document.querySelectorAll('.feed-tab');
        
        feedTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                // Remove active class from all tabs
                feedTabs.forEach(t => t.classList.remove('active'));
                // Add active class to clicked tab
                tab.classList.add('active');
            });
        });
    }

    // Tweet composer functionality
    setupTweetComposer() {
        const textarea = document.querySelector('.composer-content textarea');
        const postBtn = document.querySelector('.composer-actions .btn--primary');
        
        if (textarea && postBtn) {
            // Auto-resize textarea
            textarea.addEventListener('input', () => {
                textarea.style.height = 'auto';
                textarea.style.height = Math.min(textarea.scrollHeight, 200) + 'px';
                
                // Enable/disable post button based on content
                const hasContent = textarea.value.trim().length > 0;
                postBtn.disabled = !hasContent;
                postBtn.style.opacity = hasContent ? '1' : '0.5';
            });

            // Handle post button click
            postBtn.addEventListener('click', () => {
                if (textarea.value.trim()) {
                    this.createNewTweet(textarea.value.trim());
                    textarea.value = '';
                    textarea.style.height = 'auto';
                    postBtn.disabled = true;
                    postBtn.style.opacity = '0.5';
                }
            });

            // Handle keyboard shortcuts
            textarea.addEventListener('keydown', (e) => {
                if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                    if (textarea.value.trim()) {
                        postBtn.click();
                    }
                }
            });
        }
    }

    // Create new tweet (demo functionality)
    createNewTweet(content) {
        const tweetFeed = document.querySelector('.tweet-feed');
        const newTweet = document.createElement('article');
        newTweet.className = 'tweet';
        
        const now = new Date();
        const timeString = 'now';
        
        newTweet.innerHTML = `
            <div class="tweet-avatar">
                <div class="avatar">You</div>
            </div>
            <div class="tweet-content">
                <div class="tweet-header">
                    <span class="tweet-name">You</span>
                    <span class="tweet-username">@you</span>
                    <span class="tweet-time">${timeString}</span>
                </div>
                <div class="tweet-text">${this.escapeHtml(content)}</div>
                <div class="tweet-actions">
                    <button class="action-btn">
                        <span class="action-icon">💬</span>
                        <span class="action-count">0</span>
                    </button>
                    <button class="action-btn">
                        <span class="action-icon">🔄</span>
                        <span class="action-count">0</span>
                    </button>
                    <button class="action-btn">
                        <span class="action-icon">❤️</span>
                        <span class="action-count">0</span>
                    </button>
                    <button class="action-btn">
                        <span class="action-icon">📊</span>
                        <span class="action-count">0</span>
                    </button>
                </div>
            </div>
        `;
        
        // Insert at the beginning of the feed
        tweetFeed.insertBefore(newTweet, tweetFeed.firstChild);
        
        // Setup actions for the new tweet
        this.setupTweetActionsForElement(newTweet);
        
        // Smooth scroll to show the new tweet
        newTweet.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    // Tweet actions functionality
    setupTweetActions() {
        const tweets = document.querySelectorAll('.tweet');
        tweets.forEach(tweet => {
            this.setupTweetActionsForElement(tweet);
        });
    }

    setupTweetActionsForElement(tweet) {
        const actionBtns = tweet.querySelectorAll('.action-btn');
        
        actionBtns.forEach((btn, index) => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                this.handleTweetAction(btn, index);
            });
        });
    }

    handleTweetAction(btn, actionType) {
        const countSpan = btn.querySelector('.action-count');
        const currentCount = this.parseCount(countSpan.textContent);
        
        // Toggle active state
        const isActive = btn.classList.contains('active');
        
        if (isActive) {
            btn.classList.remove('active');
            countSpan.textContent = this.formatCount(Math.max(0, currentCount - 1));
        } else {
            btn.classList.add('active');
            countSpan.textContent = this.formatCount(currentCount + 1);
        }

        // Add specific styling for different action types
        switch (actionType) {
            case 0: // Reply
                btn.style.color = isActive ? '#71767b' : '#1d9bf0';
                break;
            case 1: // Retweet
                btn.style.color = isActive ? '#71767b' : '#00ba7c';
                break;
            case 2: // Like
                btn.style.color = isActive ? '#71767b' : '#f91880';
                break;
            case 3: // Views
                // Views don't toggle
                break;
        }
    }

    // Follow button functionality
    setupFollowButtons() {
        const followBtns = document.querySelectorAll('.follow-widget .btn--outline');
        
        followBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const isFollowing = btn.textContent.trim() === 'Following';
                
                if (isFollowing) {
                    btn.textContent = 'Follow';
                    btn.classList.remove('btn--primary');
                    btn.classList.add('btn--outline');
                } else {
                    btn.textContent = 'Following';
                    btn.classList.remove('btn--outline');
                    btn.classList.add('btn--primary');
                }
            });
        });
    }

    // Responsive handlers
    setupResponsiveHandlers() {
        let resizeTimer;
        
        window.addEventListener('resize', () => {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(() => {
                this.handleResize();
            }, 250);
        });
    }

    handleResize() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.querySelector('.mobile-overlay');
        const menuToggle = document.getElementById('menuToggle');
        
        // Close mobile menu on resize to larger screen
        if (window.innerWidth >= 768 && sidebar && sidebar.classList.contains('mobile-open')) {
            this.closeMobileMenu(sidebar, overlay, menuToggle);
        }
    }

    // Utility functions
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    parseCount(countString) {
        if (!countString || countString === '0') return 0;
        
        const cleanString = countString.toLowerCase().replace(/,/g, '');
        
        if (cleanString.includes('k')) {
            return Math.floor(parseFloat(cleanString) * 1000);
        } else if (cleanString.includes('m')) {
            return Math.floor(parseFloat(cleanString) * 1000000);
        }
        
        return parseInt(cleanString) || 0;
    }

    formatCount(count) {
        if (count === 0) return '0';
        if (count < 1000) return count.toString();
        if (count < 1000000) return (count / 1000).toFixed(1).replace('.0', '') + 'k';
        return (count / 1000000).toFixed(1).replace('.0', '') + 'm';
    }
}

// Navigation functionality
class Navigation {
    constructor() {
        this.setupNavigation();
    }

    setupNavigation() {
        // Setup sidebar navigation
        const sidebarNavItems = document.querySelectorAll('.sidebar .nav-item');
        sidebarNavItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                this.setActiveNavItem(sidebarNavItems, item);
            });
        });

        // Setup bottom navigation
        const bottomNavItems = document.querySelectorAll('.bottom-nav-item');
        bottomNavItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                this.setActiveNavItem(bottomNavItems, item);
            });
        });
    }

    setActiveNavItem(navItems, activeItem) {
        navItems.forEach(item => item.classList.remove('active'));
        activeItem.classList.add('active');
    }
}

// Search functionality
class Search {
    constructor() {
        this.setupSearch();
    }

    setupSearch() {
        const searchInput = document.querySelector('.search-input');
        
        if (searchInput) {
            let searchTimeout;
            
            searchInput.addEventListener('input', (e) => {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(() => {
                    this.performSearch(e.target.value);
                }, 300);
            });

            searchInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    this.performSearch(e.target.value);
                }
            });
        }
    }

    performSearch(query) {
        if (query.trim().length > 0) {
            console.log('Searching for:', query);
            // In a real app, this would make an API call
        }
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    const app = new TwitterApp();
    const navigation = new Navigation();
    const search = new Search();
    
    // Add some enhanced interactions
    document.addEventListener('click', (e) => {
        // Handle trend item clicks
        if (e.target.closest('.trend-item')) {
            const trendHashtag = e.target.closest('.trend-item').querySelector('.trend-hashtag');
            if (trendHashtag) {
                console.log('Clicked trend:', trendHashtag.textContent);
            }
        }
        
        // Handle show more buttons
        if (e.target.classList.contains('show-more')) {
            e.preventDefault();
            console.log('Show more clicked');
        }
    });

    // Handle scroll events for infinite scroll simulation
    let isLoading = false;
    const mainContent = document.querySelector('.main-content');
    
    if (mainContent) {
        mainContent.addEventListener('scroll', () => {
            if (isLoading) return;
            
            const { scrollTop, scrollHeight, clientHeight } = mainContent;
            
            if (scrollTop + clientHeight >= scrollHeight - 1000) {
                isLoading = true;
                // Simulate loading more tweets
                setTimeout(() => {
                    console.log('Loading more tweets...');
                    isLoading = false;
                }, 1000);
            }
        });
    }
});

// Handle focus trap for mobile menu
function trapFocus(element) {
    const focusableElements = element.querySelectorAll(
        'a[href], button, textarea, input[type="text"], input[type="radio"], input[type="checkbox"], select'
    );
    const firstFocusableElement = focusableElements[0];
    const lastFocusableElement = focusableElements[focusableElements.length - 1];

    element.addEventListener('keydown', (e) => {
        if (e.key === 'Tab') {
            if (e.shiftKey) {
                if (document.activeElement === firstFocusableElement) {
                    lastFocusableElement.focus();
                    e.preventDefault();
                }
            } else {
                if (document.activeElement === lastFocusableElement) {
                    firstFocusableElement.focus();
                    e.preventDefault();
                }
            }
        }
    });
}